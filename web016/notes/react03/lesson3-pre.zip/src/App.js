import React from "react";
import ReactReduxPage from "./pages/ReactReduxPage";

function App() {
  return (
    <div className="App">
      {/* 学习react redux */}
      <ReactReduxPage />
    </div>
  );
}

export default App;
