# docker_ci
测试使用Docker / Github Webhook实现CI持续集成

- docker-compose
- gitlab webhooks


## 示例代码运行
- NodeJS 8.0 need https://nodejs.org/en/
- Clone or download this repository
Enter your local directory, and 
- start webhooks watcher
``` bash
npm install
npx ## 示例代码运行
- NodeJS 10 need https://nodejs.org/en/
- Clone or download this repository
Enter your local directory, and 
- install dependencies:
``` bash
npm install
npm install pm2 -g
pm2 start webhooks.js --watch

```




设置Webhooks











