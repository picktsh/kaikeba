'use strict';

module.exports = require('scheduler/unstable_mock');
