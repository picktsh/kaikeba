module.exports = require('./dist/frontend');
