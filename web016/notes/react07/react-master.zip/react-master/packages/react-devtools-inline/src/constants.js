/** @flow */

export const MESSAGE_TYPE_GET_SAVED_PREFERENCES =
  'React::DevTools::getSavedPreferences';
export const MESSAGE_TYPE_SAVED_PREFERENCES =
  'React::DevTools::savedPreferences';
