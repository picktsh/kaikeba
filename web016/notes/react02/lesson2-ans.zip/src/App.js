import React from "react";
import CaculatorPage from "./pages/CaculatorPage";

function App() {
  return (
    <div className="App">
      {/* 实现输入框的加减法，比如说输入10，加10，用上combineReducers。 */}
      <CaculatorPage />
    </div>
  );
}

export default App;
