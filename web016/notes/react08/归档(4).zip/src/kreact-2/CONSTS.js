export const UPDATE = "UPDATE";
export const PLACEMENT = "PLACEMENT";
export const DELETION = "DELETION";
