export default class Component {
  static isReactComponent = {};
  constructor(props) {
    this.props = props;
  }
  // render() {
  //   return "ooo";
  // }
}

// export default function Component(props) {
//   this.props = props;

// }

// Component.prototype.isReactComponent = {};
