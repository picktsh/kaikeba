import 'package:flutter/cupertino.dart';

class GestureTask extends StatelessWidget {
  const GestureTask({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return new GestureDetector(
      
      /*点击*/
      onTap: (){
        print("onTap");
      },

      /*长按*/
      onLongPress: (){
        print("onLongPress");
      },

      onScaleStart: (startDetails){
          print("onScaleStart");
      },

      onScaleUpdate: (upDateDetails) {
        print("onScaleUpdate");
      },

      onScaleEnd: (endDetails) {
        print("onScaleEnd");
      },

      child: Container(
        child: new Container(
          color: Color.fromARGB(255, 220, 220, 220),
          child: new Center(
            child: Text("Flutter手势"),
          ),
        ),
      ),
    );
  }
}