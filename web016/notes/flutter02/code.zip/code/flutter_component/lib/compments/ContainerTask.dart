import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ContainerTask extends StatelessWidget {
  const ContainerTask({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // return Container(
    //   //没有子节点的时候，container的大小是竟可能的打，除非加入约束
    //   //如果有子节点，大小会按照子节点大小去适应
    //   color: Colors.red,
    //   child: Text('这是一个文本'),
    //   // width: 200,
    //   // height: 300,
    //   //margin: EdgeInsets.all(20),
    //   // constraints: BoxConstraints(
    //   //  maxHeight: 300,
    //   //  maxWidth: 200,
    //   //  minWidth: 150,
    //   //  minHeight: 100
    //   // ),
    //   constraints: BoxConstraints.expand(),
    // );

    // return Center(
    //     child: Container(
    //       color: Colors.red,
    //       width: 200,
    //       height: 300,
    //       child: Text(
    //         '文本',
    //         style: TextStyle(
    //           fontSize: 30,
    //           color: Colors.blue
    //         ),
    //       ), 
    //       //alignment: Alignment.bottomLeft,
    //       alignment: Alignment(-0.5,0),
    //   ),
    // );

    // return Center(
    //     child: Container(
    //       color: Colors.red,
    //       child: Transform.scale(
    //         scale: 1.5,
    //         child: FlutterLogo(
    //           size: 200,
    //         ),
    //       ),
    //   ),
    // );

    return Padding(
      // padding: EdgeInsets.all(20),
      //padding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
      //padding: EdgeInsets.fromLTRB(10, 20, 10, 20),
      padding: EdgeInsets.only(left: 10,right: 20),
      child: Container(
        color: Colors.red,
      ),
    );
  }
}