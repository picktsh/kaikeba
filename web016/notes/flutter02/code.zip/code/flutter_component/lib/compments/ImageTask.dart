import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ImageTask extends StatelessWidget {
  const ImageTask({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new Image.asset(
                'assets/images/owl.jpg',
                width: 120,
                height: 120
                ),
              new Image.network(
                'https://flutter.io/images/homepage/header-illustration.png',
                width: 120,
                height: 120
              ),
              new CircleAvatar(
                backgroundImage: new NetworkImage('https://flutter.io/images/homepage/header-illustration.png'), 
                radius: 50
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
             new FadeInImage.assetNetwork(
               placeholder: 'assets/images/owl.jpg',
               image: 'https://flutter.io/images/homepage/header-illustration.png',
                width: 120,
                height: 120
              ),
              new Image.asset(
                'assets/images/owl.jpg',
                width: 200,
                height: 100,
                fit: BoxFit.contain,  
                //repeat: ImageRepeat.repeatY,
              ),
           ], 
          ),
          new Text(
            '这是一个文本这是一个文本这是一个文本这是一个文本这是一个文本这是一个文本这是一个文本',
            style: new TextStyle(
              color:Colors.red,
              fontSize: 20.0,
              fontStyle: FontStyle.italic
            ),
             textAlign: TextAlign.center,
            // textDirection: TextDirection.rtl,
            softWrap: false,
          ),
          new Text.rich(
            new TextSpan(
              text: "文本一",
              style: new TextStyle(
                color: Colors.blue,
                fontSize: 30.0
              ),
              children: <TextSpan>[
                new TextSpan(
                  text: "文本二",
                  style: new TextStyle(
                    color: Colors.red,
                    fontSize: 20.0
                  ),
                )
              ]
            )
          ),
        ], 
      );
  }
}