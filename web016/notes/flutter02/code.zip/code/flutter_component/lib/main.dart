import 'package:flutter/material.dart';
import 'package:flutter_component/compments/ButtonTask.dart';
import 'package:flutter_component/compments/ContainerTask.dart';
import 'package:flutter_component/compments/GestureTask.dart';
import 'package:flutter_component/compments/ListViewTask.dart';

import 'compments/ImageTask.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'flutter class'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      /*body: Center(
        child: new Image.asset(
        'assets/images/owl.jpg',
        width: 200,
        height: 200), 
      )*/
      //body: ImageTask() 
      // body: ButtonTask() 
      // body: ContainerTask() 
      // body: GestureTask() 
      body: ListViewTask(),
    );
  }
}
