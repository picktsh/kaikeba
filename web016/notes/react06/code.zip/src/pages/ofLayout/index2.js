
import styles from './index2.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page index2</h1>
    </div>
  );
}
