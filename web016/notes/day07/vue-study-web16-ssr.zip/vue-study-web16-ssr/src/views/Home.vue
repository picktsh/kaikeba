<template>
  <div class="home">
    home page
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'home'
}
</script>
