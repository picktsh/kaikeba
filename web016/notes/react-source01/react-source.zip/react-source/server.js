// 未来开发环境，仕可以取代webpak的，不用打包 秒开
const fs = require('fs')
const path = require('path')
const Koa = require('koa')

const app = new Koa()
function rewriteImport(content){
  return content.replace(/from ['"]([^'"]+)['"]/g, function(s0,s1){
    // . ../ /开头的，都是相对路径
    if(s1[0]!=='.'&& s1[1]!=='/'){
      return `from '/@modules/${s1}'`
    }else{
      return s0
    }
  })
}
// 热更新，用socket.io 后端文件变了，推给前端

app.use(async ctx=>{
  // 拦截所有的请求
  // 代码编译，less .vue,sass,jsx ，ts都在这里实现
  const {request:{url}} = ctx
  if(url=='/'){
    ctx.type = 'text/html'
    ctx.body = fs.readFileSync('./index.html','utf-8')
  }else if(url.endsWith('.js')){
    const p = path.resolve(__dirname, url.slice(1))
    console.log(p)
    ctx.type = 'application/javascript'
    const content = fs.readFileSync(p,'utf-8')
    ctx.body = rewriteImport(content)
    // @todo 要针对nodeule做一些代码替换 加标记  /@node_modules/ 

  }else if(url.endsWith('.css')){
    // .less.sass.stylus
    const p = path.resolve(__dirname, url.slice(1))
    ctx.type = 'application/javascript'
    const content = fs.readFileSync(p,'utf-8')
    // 加上一些css的预处理
    const ret = `
const css = "${content.replace(/\n/g,'')}"
const link = document.createElement('style')
link.setAttribute('type','text/css')
document.body.appendChild(link)
link.innerHTML = css
export default css
    
    `
    
    ctx.body = ret
  }else if(url.startsWith('/@modules/')){
    // 这是一个node_module里的东西
    const prefix = path.resolve(__dirname,'node_modules',url.replace('/@modules/',''))
    const module = require(prefix+'/package.json').module
    const p = path.resolve(prefix,module)
    const ret = fs.readFileSync(p,'utf-8')
    ctx.type = 'application/javascript'
    ctx.body = rewriteImport(ret)
  }else if(url.endsWith('.jsx')){
    // 文件做jsx解析， 用babel插件即可

  }else if(url.endsWith('.vue')){
    // vue单文件解析，返回js内容，让浏览器再发起一次temokate 或者一次性解决

  }else if(url.endsWith('.less')){}
})

app.listen('3001',()=>{
  console.log('3001')
})