

export function log(msg){
  console.log(msg)
}