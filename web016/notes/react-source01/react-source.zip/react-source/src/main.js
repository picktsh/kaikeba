// 直接走es6的import
import {log} from './util.js'
import {createApp} from 'vue'
import './index.css'
// 支持css和webpack的css-loader思路仕一样的 
log('xx')
console.log(createApp)
