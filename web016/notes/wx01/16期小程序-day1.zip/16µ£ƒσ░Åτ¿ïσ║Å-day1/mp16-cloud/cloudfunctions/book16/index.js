// 云函数入口文件
// 云函数？就是一个node应用！！！！！
const cloud = require("wx-server-sdk");
const axios = require("axios");
const doubanbook = require("doubanbook");

cloud.init();

async function getDoubanBook(isbn) {
  let url = "https://search.douban.com/book/subject_search?search_text=" + isbn;
  const res = await axios.get(url);
  let reg = /window\.__DATA__ = "(.*)"/;

  if (reg.test(res.data)) {
    console.log(RegExp.$1);
    let searchData = doubanbook(RegExp.$1)[0];
    return searchData;
  }
}

// getDoubanBook("9787121139512");

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();

  let { isbn } = event;
  let bookInfo = await getDoubanBook(isbn);
  return {
    title: bookInfo.title,
    url: bookInfo.url,
    image: bookInfo.cover_url,
  };
};
