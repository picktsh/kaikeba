export const add = (a, b) => {
  return a + b;
};

export const minus = (a, b) => {
  return a - b;
};
