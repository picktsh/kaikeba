
// 代码；逻辑
// 测试就是给定的输入，判断期望的输出
// 怎么测试这个代码呢
function add(a,b){
  if(Number(a)==a && Number(b)==b){
    return Number(a)+Number(b)
  }else if(typeof a=="object" && typeof b=="object"){
    return Object.assign({},a,b)
  }
  return a+b
}