import React, {Component} from "react";
import "./HomePage.less";

export default class HomePage extends Component {
  render() {
    return (
      <div className="homePage">
        <h3>HomePage</h3>
      </div>
    );
  }
}
