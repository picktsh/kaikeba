import React from "react";
// import Button from "antd/es/button";
// import "antd/dist/antd.css";

import {Button} from "antd";
import HomePage from "./pages/HomePage";

function App() {
  return (
    <div className="App">
      app
      <Button type="primary">提交</Button>
      <HomePage />
    </div>
  );
}

export default App;
