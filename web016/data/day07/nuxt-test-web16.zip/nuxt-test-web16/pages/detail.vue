<template>
  <div>
    <h2>detail page</h2>

    <!-- nuxt-child表示嵌套关系 -->
    <!-- 类似router-view -->
    <nuxt-child></nuxt-child>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style lang="scss" scoped>

</style>