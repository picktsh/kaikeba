import React from "react";

import ReduxPage from './pages/ReduxPage.js'

function App() {
  return (
    <div className="App">
      <h3>写点东西表示页面正常</h3>
      {/* Redux学习 */}
      <ReduxPage/>
    </div>
  );
}

export default App;
