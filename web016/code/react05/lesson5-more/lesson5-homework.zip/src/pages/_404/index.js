import React, {Component} from "react";

export default class _404 extends Component {
  render() {
    return (
      <div>
        <h3>404</h3>
      </div>
    );
  }
}
