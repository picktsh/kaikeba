{
  "name": "mock-server",
  "description": "mock-server",
  "scripts": {
    "start": "json-server --watch ../mock/index.js --host=192.168.43.27 --port 3001"
  },
  "dependencies": {
    "json-server": "^0.14.0"
  },
  "devDependencies": {}
}