const getUserInfo = {
  "id": null,
  "userName": "gaoshaoyun",
  "mobile": "185****1324",
  "headIcon": "https://img11.360buyimg.com/jdphoto/s120x120_jfs/t21160/90/706848746/2813/d1060df5/5b163ef9N4a3d7aa6.png"
}
const login = {
  "id": 1,
  "userName": "gaoshaoyun",
  "mobile": "185****1324",
  "headIcon": "https://img11.360buyimg.com/jdphoto/s120x120_jfs/t21160/90/706848746/2813/d1060df5/5b163ef9N4a3d7aa6.png"
}
const logout = {
}
module.exports = () => {
  return {
    getUserInfo,
    login,
    logout
  }
}