import React, { Component } from "react";
import PageLayout from "../../layout/PageLayout";

export default class MyTaobaoPage extends Component {
    render() {
        return <PageLayout>MyTaobaoPage</PageLayout>;
    }
}
