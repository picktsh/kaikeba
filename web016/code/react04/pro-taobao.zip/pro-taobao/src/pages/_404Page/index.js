import React, { Component } from "react";
import PageLayout from "../../layout/PageLayout";

export default class _404Page extends Component {
    render() {
        return <PageLayout>_404Page</PageLayout>;
    }
}
