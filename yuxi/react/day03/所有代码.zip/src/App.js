import React from "react";
// import LifeCyclePage from "./pages/LifeCyclePage";
import PureComponentPage from "./pages/PureComponentPage";
// import HookPage from "./pages/HookPage";
// import FunctionComponent from "./pages/FunctionComponent";
// import ClassComponent from "./pages/ClassComponent";
// import ReduxPage from "./pages/ReduxPage";
// import ReactReduxPage from "./pages/ReactReduxPage";
// import RouterPage from "./pages/RouterPage";
// import CustomHookPage from "./pages/CustomHookPage";
// import UseMemoPage from "./pages/UseMemoPage";
// import UseCallbackPage from "./pages/UseCallbackPage";

export default function App() {
  return (
    <div>
      <PureComponentPage />
    </div>
  );
}
