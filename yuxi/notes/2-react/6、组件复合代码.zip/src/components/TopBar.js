import React, { Component } from "react";

export default class TopBar extends Component {
  render() {
    return (
      <div className="topBar">
        <h3>TopBar</h3>
      </div>
    );
  }
}
