import React from "react";
import LifeCyclePage from "./pages/LifeCyclePage";
import HomePage from "./pages/HomePage";
import UserPage from "./pages/UserPage";

export default function App() {
  return (
    <div>
      {/* <UserPage /> */}
      <HomePage />
    </div>
  );
}
