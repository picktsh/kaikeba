import VueRouter from 'vue-router'

declare const router: VueRouter

export default router